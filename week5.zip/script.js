//create selected node
var selectedNode = null;

//select node
function select(el) {
    // remove outline from current selection
    if (selectedNode) {
        selectedNode.style.border = "1px solid black"; 
    }
    // set new selection and outline it
    selectedNode = el;
    el.style.border = "3px dotted red";
}

//create table
var table = document.createElement("table");

var thead = document.createElement("thead");
table.appendChild(thead);

var trhead = document.createElement("tr");
thead.appendChild(trhead);

for (var i = 1; i < 5; i++) {
	var thhead = document.createElement("th");
	thhead.textContent = "Header " + i;
	trhead.appendChild(thhead);
}

var tbody = document.createElement("tbody");
table.appendChild(tbody);

for (var i = 1; i < 5; i++) {
	var trbody = document.createElement("tr");
	tbody.appendChild(trbody);
	
	for (var n = 1; n < 5; n++) {
		var td_tr = document.createElement("td");
		td_tr.textContent = n + ", " + i;
		trbody.appendChild(td_tr);	
	}
}

select(tbody.firstElementChild.firstElementChild);

document.body.appendChild(table);

//create up button
var upButton = document.createElement("button");
upButton.textContent = "UP";
upButton.setAttribute('id', 'UP');
upButton.style.marginRight = "5px";
document.body.appendChild(upButton);
document.getElementById("UP").addEventListener("click", upButtonClick);

function upButtonClick(event){
    console.log("UP"); 
 	var upTr = selectedNode.parentNode.previousElementSibling;
	if (upTr) {
	    select(upTr.children[selectedNode.cellIndex]);
	}
}

//create down button
var downButton = document.createElement("button");
downButton.textContent = "DOWN";
downButton.setAttribute('id', 'DOWN');
downButton.style.marginRight = "5px";
document.body.appendChild(downButton);
document.getElementById("DOWN").addEventListener("click", downButtonClick);

function downButtonClick(event){
    console.log("DOWN");  
	var downTr = selectedNode.parentNode.nextElementSibling;
	if (downTr) {
	    select(downTr.children[selectedNode.cellIndex]);
	}
}

//create right button
var rightButton = document.createElement("button");
rightButton.textContent = "RIGHT";
rightButton.setAttribute('id', 'RIGHT');
rightButton.style.marginRight = "5px";
document.body.appendChild(rightButton);
document.getElementById("RIGHT").addEventListener("click", rightButtonClick);

function rightButtonClick(event){
    console.log("RIGHT"); 
	var rightTr = selectedNode.nextElementSibling;
	if (rightTr) {
	    select(rightTr);
	} 
}

//create left button
var leftButton = document.createElement("button");
leftButton.textContent = "LEFT";
leftButton.setAttribute('id', 'LEFT');
leftButton.style.marginRight = "5px";
document.body.appendChild(leftButton);
document.getElementById("LEFT").addEventListener("click", leftButtonClick);

function leftButtonClick(event){
    console.log("LEFT"); 
	var leftTr = selectedNode.previousElementSibling;
	if (leftTr) {
	    select(leftTr);
	} 
}

//create mark button
var markButton = document.createElement("button");
markButton.textContent = "Mark Cell";
markButton.setAttribute('id', 'markCell');
markButton.style.marginTop = "10px";
document.body.appendChild(markButton);
document.getElementById("markCell").addEventListener("click", markButtonClick);

function markButtonClick(){
    selectedNode.style.backgroundColor = "yellow";  
}